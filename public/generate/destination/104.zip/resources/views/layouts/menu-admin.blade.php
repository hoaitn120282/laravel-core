<li><a href="">Nav item</a></li>
<li><a href="">Nav item again</a></li>
@yield('menu-item')