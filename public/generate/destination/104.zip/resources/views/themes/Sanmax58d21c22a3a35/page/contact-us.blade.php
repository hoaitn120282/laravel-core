@extends(Theme::active().'.main')

@section('content')
<div class="content content-contact">
    <div class="container">
        <section class="contact bg-white">
            <header>
                <h1>{{ $model->post_title }}</h1>
                <p>{!!html_entity_decode($model->post_content)!!}</p>
            </header>
            <div class="contact-info">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="detail text-center">
                            <span><i class="fa fa-map-marker"></i></span>
                            <p class="type">Address</p>
                            <p class="type-dt mtop-5">123 Fake Street, Fake City,<br />
                                Fake Country</p>

                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="detail text-center">
                            <span><i class="fa fa-phone"></i></span>
                            <p class="type">Phone number</p>
                            <p class="type-dt">+401 111 222 xxx</p>

                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="detail text-center">
                            <span><i class="fa fa-envelope"></i></span>
                            <p class="type">Email address</p>
                            <p class="type-dt">companyname@support.com</p>

                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                        <div class="detail text-center">
                            <span><i class="fa fa-skype"></i></span>
                            <p class="type">Skype</p>
                            <p class="type-dt">companyname.skype</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End New Detail-->
    </div>

    @if(Widget::existsGroup('contact_info'))
        {{ Widget::group('contact_info') }}
    @endif

</div>
@endsection

@section('appTitle')
    {{ $appTitle or $model->post_title }}
@endsection
