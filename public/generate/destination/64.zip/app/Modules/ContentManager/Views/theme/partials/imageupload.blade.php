<div class="generator-btn-img" style="margin-bottom:10px">
<div class="row">
	<div class="col-md-8 text-center label">
		<h3>{{ $data['label'] }}</h3>
	</div>
	<div class="col-md-4">
		 @include('ContentManager::partials.btnUpload') 
	</div>
</div>
</div>
