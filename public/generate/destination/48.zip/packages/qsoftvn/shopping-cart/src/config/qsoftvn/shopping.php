<?php
return [
    'uri_prefix' => 'shopping-cart',
];
