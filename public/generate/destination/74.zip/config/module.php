<?php
return [
    'modules' => [
        'ContentManager' => 'contentManager.index',
        'TemplateManager' => 'templateManager.index',
        'SiteManager' => 'siteManager.index',
        'LanguageManager' => 'languageManager.index',
    ],
    'backend' => 'admin'
];