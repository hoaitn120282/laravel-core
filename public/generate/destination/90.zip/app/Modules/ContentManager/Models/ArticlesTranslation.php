<?php

namespace App\Modules\ContentManager\Models;

use Illuminate\Database\Eloquent\Model;

class ArticlesTranslation extends Model
{
    protected $primaryKey = 'post_translations_id';
    protected $table = 'post_translations';
}
