<?php

namespace Qsoftvn\ShoppingCart\Http\Controllers;

class IndexController extends Controller
{

    /**
     * [index description]
     * @return [type] [description]
     */
    public function index()
    {
        return 'Shopping Cart';
    }
}
