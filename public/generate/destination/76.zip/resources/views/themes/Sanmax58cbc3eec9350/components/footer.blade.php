<footer class="bg-top-bottom">
    <div class="container">
        <p class="">Powered by Sanmax #afsprakenbeheer.</p>
    </div>
</footer>

