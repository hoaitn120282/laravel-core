@extends(Theme::active().'.main')

@section('content')
    <section class="content-dt content-contact">
        <div class="ct-detail">
            <h3>{{ $model->post_title }}</h3>
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>

            <ul class="contact-info list-unstyled">
                <li><span>Address</span> 123 Fake Street, Fake City, Fake Country</li>
                <li><span>Phone number</span> +401 111 222 xxx</li>
                <li><span>Email  address</span> companyname@support.com</li>
                <li><span>Skype</span> companyname.skype</li>
            </ul>

            <div class="contact-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.0405366193354!2d105.78919731545666!3d21.031063971852408!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab31fa9089bd%3A0xab696ce4f403011!2sQSoft+Vietnam!5e0!3m2!1svi!2s!4v1487733047422" width="600" height="450" frameborder="0" style="border:0; width: 100%" allowfullscreen></iframe>
            </div>
        </div>
    </section>
@endsection

@section('appTitle')
    {{ $appTitle or $model->post_title }}
@endsection
