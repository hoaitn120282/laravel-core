<div class="form-group">
    <label for="title" class="control-label">Title</label>
    <input id="title" value="{{ $options['title'] }}" class="form-control" type="text" name="title">
</div>
<div class="form-group">
    <label for="title" class="control-label">Text / HTML</label>
    <textarea class="form-control" name="text" rows="3">{{ $options['text'] }}</textarea>
</div>