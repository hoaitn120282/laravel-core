<div class="container">
    <div class="content">
        @yield('content')
    </div>
</div>
