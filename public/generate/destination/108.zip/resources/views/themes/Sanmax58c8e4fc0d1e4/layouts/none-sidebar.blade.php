<div class="content">
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">@yield('content')</div>
			</div>
		</div>
	</div>
</div>