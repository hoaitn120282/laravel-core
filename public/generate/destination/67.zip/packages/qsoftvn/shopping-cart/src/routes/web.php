<?php

/**
 * Shopping cart routes
 */

Route::get('/', 'IndexController@index');
