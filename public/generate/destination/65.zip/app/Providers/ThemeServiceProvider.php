<?php

namespace App\Providers;
use App\Themes\Theme;
use Illuminate\Support\ServiceProvider;
use View;
class ThemeServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
       
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(Theme::class, function ($app) {
            return new Theme();
        });
    }
}
