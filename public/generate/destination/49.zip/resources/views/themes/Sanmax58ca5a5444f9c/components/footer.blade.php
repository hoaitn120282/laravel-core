
<!--Begin Footer-->
<footer class="bg-top-bottom">
    <div class="container">
        <p class="">{{ Theme::option('general','copyright') }}</p>
    </div>
</footer>
<!--End Footer-->