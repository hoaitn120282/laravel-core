<?php

namespace App\Modules\ContentManager\Models;

use Illuminate\Database\Eloquent\Model;

class TermsTranslation extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'term_translations';
}
