@extends(Theme::active().'.main')

@section('content')
<div class="content content-contact">
    <div class="container">
        <section class="contact bg-white">
            <header>
                <h1>{{ $model->post_title }}</h1>
                <p>{!!html_entity_decode($model->post_content)!!}</p>
            </header>
            <div class="contact-info">
            @if(Widget::existsGroup('contact_info'))
                <div class="row">
                {{ Widget::group('contact_info') }}
                </div>
            @endif
            </div>
        </section>
        <!--End New Detail-->
    </div>

    @if(Widget::existsGroup('contact_bottom'))
        {{ Widget::group('contact_bottom') }}
    @endif

</div>
@endsection

@section('appTitle')
    {{ $appTitle or $model->post_title }}
@endsection
