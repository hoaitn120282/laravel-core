<div class="content">
    @yield('content')
</div>
