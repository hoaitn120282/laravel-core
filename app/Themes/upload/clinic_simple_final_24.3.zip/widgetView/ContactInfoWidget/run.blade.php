<?php $locale = Trans::locale() ?>
<li><span>{{ $options["title_{$locale}"] }}</span>{{ $options["description_{$locale}"] }}</li>